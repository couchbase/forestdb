make clean | grep -E "warning|error" ; make -j | grep -E "warning|error"
