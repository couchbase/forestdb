/*
 * Copyright 2013 Jung-Sang Ahn <jungsang.ahn@gmail.com>.
 * All Rights Reserved.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "btree.h"
#include "btree_kv.h"
#include "memleak.h"

INLINE void _get_kv(struct bnode *node, idx_t idx, void *key, void *value)
{
    int ksize, vsize;
    void *ptr;
    _get_kvsize(node->kvsize, ksize, vsize);
    ptr = node->data + (idx * (ksize+vsize));

    memcpy(key, ptr, ksize);
    if (value) {
        memcpy(value, ptr + ksize, vsize);
    }
}

INLINE void _set_kv(struct bnode *node, idx_t idx, void *key, void *value)
{
    int ksize, vsize;
    void *ptr;
    _get_kvsize(node->kvsize, ksize, vsize);
    ptr = node->data + (idx * (ksize+vsize));

    memcpy(ptr, key, ksize);
    memcpy(ptr + ksize, value, vsize);
}

INLINE void _ins_kv(struct bnode *node, idx_t idx, void *key, void *value)
{
    int ksize, vsize, kvsize;
    void *ptr;
    _get_kvsize(node->kvsize, ksize, vsize);
    kvsize = ksize + vsize;
    ptr = node->data;

    if (key && value) {
        // insert
        memmove(
            ptr + (idx+1)*kvsize,
            ptr + idx*kvsize,
            (node->nentry - idx)*kvsize);
        memcpy(ptr + idx*kvsize, key, ksize);
        memcpy(ptr + idx*kvsize + ksize, value, vsize);
    }else{
        // remove
        memmove(
            ptr + idx*kvsize,
            ptr + (idx+1)*kvsize,
            (node->nentry - (idx+1))*kvsize);
    }
}

INLINE void _copy_kv(
    struct bnode *node_dst, struct bnode *node_src, idx_t dst_idx, idx_t src_idx, idx_t len)
{
    int ksize, vsize, kvsize;
    void *ptr_src, *ptr_dst;

    if (node_dst == node_src) return;

    _get_kvsize(node_src->kvsize, ksize, vsize);
    kvsize = ksize + vsize;

    ptr_src = node_src->data;
    ptr_dst = node_dst->data;

    memcpy(
        ptr_dst + kvsize * dst_idx,
        ptr_src + kvsize * src_idx,
        kvsize * len);
}

INLINE size_t _get_data_size(
    struct bnode *node, void *new_minkey, void *key_arr, void *value_arr, size_t len)
{
    int ksize, vsize;
    _get_kvsize(node->kvsize, ksize, vsize);
    return node->nentry * (ksize + vsize) + ((key_arr && value_arr)?((ksize + vsize)*len):0);
}

INLINE size_t _get_kv_size(struct btree *tree, void *key, void *value)
{
    return (key)?tree->ksize:0 + (value)?tree->vsize:0;
}

INLINE void _init_kv_var(struct btree *tree, void *key, void *value)
{
    if (key) memset(key, 0, tree->ksize);
    if (value) memset(value, 0, tree->vsize);
}

INLINE void _set_key(struct btree *tree, void *dst, void *src)
{
    memcpy(dst, src, tree->ksize);
}

INLINE void _set_value(struct btree *tree, void *dst, void *src)
{
    memcpy(dst, src, tree->vsize);
}

INLINE void _get_nth_idx(struct bnode *node, idx_t num, idx_t den, idx_t *idx)
{
    size_t rem = node->nentry - (int)(node->nentry / den) * den;
    *idx = (node->nentry / den) * num + ((num < rem)?(num):(rem));
}

INLINE void _get_nth_splitter(struct bnode *prev_node, struct bnode *node, void *key)
{
    int ksize, vsize;

    _get_kvsize(node->kvsize, ksize, vsize);
    // always return the first key of the NODE
    memcpy(key, node->data, ksize);
}

INLINE bid_t _value_to_bid_64(void *value)
{
    return *((bid_t *)value);
}

INLINE void* _bid_to_value_64(bid_t *bid)
{
    return (void *)bid;
}

INLINE int _cmp_int32_t(void *key1, void *key2)
{
    int32_t *a,*b;
    a = (int32_t*)key1;
    b = (int32_t*)key2;
    if (*a<*b) return -1;
    if (*a>*b) return 1;
    return 0;
}

INLINE int _cmp_uint32_t(void *key1, void *key2)
{
    uint32_t *a,*b;
    a = (uint32_t*)key1;
    b = (uint32_t*)key2;
    if (*a<*b) return -1;
    if (*a>*b) return 1;
    return 0;
}

INLINE int _cmp_uint64_t(void *key1, void *key2)
{
    uint64_t a,b;
    a = *(uint64_t*)key1;
    b = *(uint64_t*)key2;
    /*
    if (*a<*b) return -1;
    if (*a>*b) return 1;
    return 0;*/
    return _CMP_U64(a, b);
}

INLINE int _cmp_char64(void *key1, void *key2)
{
    return strncmp((char*)key1, (char*)key2, 8);
}

INLINE int _cmp_binary32(void *key1, void *key2)
{
    #ifdef __BIT_CMP
        uint32_t a,b;
        a = bitswap32(*(uint32_t*)key1);
        b = bitswap32(*(uint32_t*)key2);
        return _CMP_U32( a, b );
    #else
        return memcmp(key1, key2, 8);
    #endif
}

INLINE int _cmp_binary64(void *key1, void *key2)
{
    #ifdef __BIT_CMP
        uint64_t a,b;
        a = bitswap64(*(uint64_t*)key1);
        b = bitswap64(*(uint64_t*)key2);
        return _CMP_U64( a , b );
    #else
        return memcmp(key1, key2, 8);
    #endif
}

// key: uint64_t, value: uint64_t
static struct btree_kv_ops kv_ops_ku64_vu64 = {
    _get_kv, _set_kv, _ins_kv, _copy_kv, _get_data_size, _get_kv_size, _init_kv_var, NULL,
    _set_key, _set_value, _get_nth_idx, _get_nth_splitter,
    _cmp_uint64_t, _value_to_bid_64, _bid_to_value_64};

static struct btree_kv_ops kv_ops_ku32_vu64 = {
    _get_kv, _set_kv, _ins_kv, _copy_kv, _get_data_size, _get_kv_size, _init_kv_var, NULL,
    _set_key, _set_value, _get_nth_idx, _get_nth_splitter,
    _cmp_uint32_t, _value_to_bid_64, _bid_to_value_64};

struct btree_kv_ops * btree_kv_get_ku64_vu64()
{
    return &kv_ops_ku64_vu64;
}

struct btree_kv_ops * btree_kv_get_ku32_vu64()
{
    return &kv_ops_ku32_vu64;
}

struct btree_kv_ops * btree_kv_get_kb64_vb64(struct btree_kv_ops *kv_ops)
{
    struct btree_kv_ops *btree_kv_ops;
    if (kv_ops) {
        btree_kv_ops = kv_ops;
    }else{
        btree_kv_ops = (struct btree_kv_ops *)malloc(sizeof(struct btree_kv_ops));
    }

    btree_kv_ops->get_kv = _get_kv;
    btree_kv_ops->set_kv = _set_kv;
    btree_kv_ops->ins_kv = _ins_kv;
    btree_kv_ops->copy_kv = _copy_kv;
    btree_kv_ops->set_key = _set_key;
    btree_kv_ops->set_value = _set_value;
    btree_kv_ops->get_data_size = _get_data_size;
    btree_kv_ops->get_kv_size = _get_kv_size;
    btree_kv_ops->init_kv_var = _init_kv_var;
    btree_kv_ops->free_kv_var = NULL;

    btree_kv_ops->get_nth_idx = _get_nth_idx;
    btree_kv_ops->get_nth_splitter = _get_nth_splitter;

    btree_kv_ops->cmp = _cmp_binary64;

    btree_kv_ops->bid2value = _bid_to_value_64;
    btree_kv_ops->value2bid = _value_to_bid_64;

    return btree_kv_ops;
}

struct btree_kv_ops * btree_kv_get_kb32_vb64(struct btree_kv_ops *kv_ops)
{
    struct btree_kv_ops *btree_kv_ops;
    if (kv_ops) {
        btree_kv_ops = kv_ops;
    }else{
        btree_kv_ops = (struct btree_kv_ops *)malloc(sizeof(struct btree_kv_ops));
    }

    btree_kv_ops->get_kv = _get_kv;
    btree_kv_ops->set_kv = _set_kv;
    btree_kv_ops->ins_kv = _ins_kv;
    btree_kv_ops->copy_kv = _copy_kv;
    btree_kv_ops->set_key = _set_key;
    btree_kv_ops->set_value = _set_value;
    btree_kv_ops->get_data_size = _get_data_size;
    btree_kv_ops->get_kv_size = _get_kv_size;
    btree_kv_ops->init_kv_var = _init_kv_var;
    btree_kv_ops->free_kv_var = NULL;

    btree_kv_ops->get_nth_idx = _get_nth_idx;
    btree_kv_ops->get_nth_splitter = _get_nth_splitter;

    btree_kv_ops->cmp = _cmp_binary32;

    btree_kv_ops->bid2value = _bid_to_value_64;
    btree_kv_ops->value2bid = _value_to_bid_64;

    return btree_kv_ops;
}


