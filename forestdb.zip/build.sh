make clean ; make -j8 | grep -E "warning|error"
