/*
 * Copyright 2013 Jung-Sang Ahn <jungsang.ahn@gmail.com>.
 * All Rights Reserved.
 */

#ifndef _JSAHN_FILEMGR_OPS_LINUX
#define _JSAHN_FILEMGR_OPS_LINUX

struct filemgr_ops * get_linux_filemgr_ops();

#endif
